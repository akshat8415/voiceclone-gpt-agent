
import os
import numpy as np
import soundfile as sf
from pathlib import Path

from encoder import inference as encoder
from synthesizer.inference import Synthesizer
from vocoder import inference as vocoder

from utils.audio_utils import preprocess_audio

# --- Paths to models ---
encoder_path = Path("encoder/saved_models/encoder.pt")
synthesizer_path = Path("synthesizer/saved_models/synthesizer.pt")
vocoder_path = Path("vocoder/saved_models/vocoder.pt")

# --- Load models ---
print("Loading models...")
encoder.load_model(encoder_path)
synthesizer = Synthesizer(synthesizer_path)
vocoder.load_model(vocoder_path)
print("Models loaded successfully.")

# --- Voice Cloning Pipeline ---
def clone_voice(source_wav_path, text, output_path="output.wav"):
    print(f"Processing voice from: {source_wav_path}")
    preprocessed_wav = preprocess_audio(source_wav_path)
    embed = encoder.embed_utterance(preprocessed_wav)

    print("Synthesizing...")
    specs = synthesizer.synthesize_spectrograms([text], [embed])
    generated_wav = vocoder.infer_waveform(specs[0])

    # Trim silence
    generated_wav = np.pad(generated_wav, (0, 4000), mode="constant")
    sf.write(output_path, generated_wav.astype(np.float32), 22050)
    print(f"Generated audio saved to: {output_path}")


# --- Example Run ---
if __name__ == "__main__":
    # Replace with your recorded voice path
    input_audio = "my_voice.wav"
    user_text = "Hello, I am your digital assistant speaking with your voice."

    clone_voice(input_audio, user_text)
